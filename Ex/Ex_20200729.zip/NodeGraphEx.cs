﻿using HumanAPI;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[RequireComponent(typeof(NodeGraph))]
public class NodeGraphEx : MonoBehaviour {

}